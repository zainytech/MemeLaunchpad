import logo from './logo.svg';
import './App.css';

import Route from './Route'

function App() {
  return (
    <div className="App">
      <Route/>
    </div>
  );
}

export default App;
